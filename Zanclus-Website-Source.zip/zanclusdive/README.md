# Zanclus Dive Center

Website responsif yang dibangun berdasarkan referensi visual dari pengguna: hero bawah laut, navigasi transparan, panel konten putih, kartu pengalaman, kalender, dan kuis.

## Menjalankan

Memerlukan Node.js 20.19+ atau 22.12+ (divalidasi dengan Node.js 24).

```sh
npm ci --cache /workspace/.npm-cache
npm run dev -- --port 5173
```

Untuk produksi:

```sh
npm run build
npm run preview -- --port 4173
```

Unggah isi `dist/` ke hosting statis. Build menggunakan path root `/`; untuk hosting di subdirektori, sesuaikan `base` Vite saat build.

## Fitur

- Tampilan desktop dan mobile, navigasi mobile, anchor sections.
- Kalender rencana dengan pergantian bulan, tanggal lampau nonaktif, serta tanggal pilihan yang diteruskan ke formulir.
- Dialog detail pengalaman dan kuis dua langkah.
- Formulir rencana diving, tautan pesan WhatsApp, dan unduhan ringkasan TXT.
- Logo SVG lokal, favicon, font lokal, gambar WebP lokal; runtime tidak memerlukan CDN.
- Validasi formulir, focus state, Escape untuk dialog, serta dukungan reduced motion.

## Kontak uji coba

Nomor WhatsApp: **085190849237**, format internasional `6285190849237`. Diberikan pengguna untuk uji coba. Ganti tautan pada `index.html` dan nomor pesan pada `src/main.js` saat nomor final tersedia.

Formulir menyiapkan pesan; pengguna tetap perlu mengirimnya di WhatsApp. Tidak ada backend, pembayaran, database, atau konfirmasi reservasi otomatis. Kalender tidak menunjukkan ketersediaan nyata. Data hanya berada dalam sesi halaman dan tidak disimpan ke server.

Lokasi, harga, sertifikasi, dan jadwal aktual belum diberikan, sehingga tidak dibuat sebagai klaim website. Gambar bawah laut dibuat secara generatif untuk konsep dan bukan dokumentasi lokasi Zanclus. Logo adalah adaptasi vektor dari aset brand sebelumnya. Font Inter dan Montserrat didapatkan dari Google Fonts; keduanya menggunakan SIL Open Font License.

## Verifikasi

```sh
npm test
node scripts/verify.mjs
```

Tes browser memerlukan server development di port 5173 dan Chromium pada `/usr/bin/chromium` (ubah `executablePath` bila berbeda). Screenshot hasil tes ada di `artifacts/` dan tidak diperlukan untuk deployment.

Lima tes logika mencakup kalender tahun kabisat, awal pekan, kunci tanggal, rekomendasi kuis, dan ringkasan rencana. Tes browser memeriksa alur desktop/mobile, detail, kalender, kuis, formulir, URL WhatsApp, unduhan, navigasi mobile, dialog, overflow, dan error runtime/network. Tes tidak mengirim pesan WhatsApp.
